(function ($){
    // Get the path to action from CakePHP
    var autoCompleteSource = urlToAutocompleteAction;
    $('#autocompleteDep').autocomplete({
        source: autoCompleteSource,
        minLength: 1
    });
    $('#autocompleteDest').autocomplete({
        source: autoCompleteSource,
        minLength: 1
    });
}) (jQuery);